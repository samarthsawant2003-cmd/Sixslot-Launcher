package com.sixslot.launcher.ui

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sixslot.launcher.data.LauncherPreferences
import com.sixslot.launcher.model.AppSlot
import com.sixslot.launcher.model.DefaultPresets
import com.sixslot.launcher.model.InstalledAppInfo
import com.sixslot.launcher.util.LauncherExitHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = LauncherPreferences(application)

    private val _slots = MutableStateFlow(
        (0 until 6).map { AppSlot(index = it, label = "Slot ${it + 1}", packageName = "") }
    )
    val slots: StateFlow<List<AppSlot>> = _slots.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _use24Hour = MutableStateFlow(DefaultPresets.DEFAULT_USE_24H)
    val use24Hour: StateFlow<Boolean> = _use24Hour.asStateFlow()

    private val _intentionNote = MutableStateFlow(DefaultPresets.DEFAULT_INTENTION)
    val intentionNote: StateFlow<String> = _intentionNote.asStateFlow()

    private val _swipeNotifications = MutableStateFlow(true)
    val swipeNotifications: StateFlow<Boolean> = _swipeNotifications.asStateFlow()

    // Upper Focus Timer State
    private val _timerTotalSeconds = MutableStateFlow(DefaultPresets.DEFAULT_TIMER_MINUTES * 60)
    val timerTotalSeconds: StateFlow<Int> = _timerTotalSeconds.asStateFlow()

    private val _timerRemainingSeconds = MutableStateFlow(DefaultPresets.DEFAULT_TIMER_MINUTES * 60)
    val timerRemainingSeconds: StateFlow<Int> = _timerRemainingSeconds.asStateFlow()

    private val _timerRunning = MutableStateFlow(false)
    val timerRunning: StateFlow<Boolean> = _timerRunning.asStateFlow()

    private var timerJob: Job? = null

    init {
        viewModelScope.launch {
            refreshInstalledApps()
            val initial = prefs.stateFlow.first()
            _use24Hour.value = initial.use24Hour
            _intentionNote.value = initial.intentionNote
            _swipeNotifications.value = initial.swipeDownNotifications
            _timerTotalSeconds.value = initial.timerDefaultMinutes * 60
            _timerRemainingSeconds.value = initial.timerDefaultMinutes * 60

            if (initial.slots != null) {
                _slots.value = initial.slots
            } else {
                val seeded = buildInitialSixSlots(_installedApps.value)
                _slots.value = seeded
                prefs.saveSlots(seeded)
            }

            prefs.stateFlow.collect { state ->
                state.slots?.let { _slots.value = it }
                _use24Hour.value = state.use24Hour
                _intentionNote.value = state.intentionNote
                _swipeNotifications.value = state.swipeDownNotifications
            }
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            val apps = withContext(Dispatchers.IO) {
                val pm = getApplication<Application>().packageManager
                val selfPkg = getApplication<Application>().packageName
                val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                pm.queryIntentActivities(mainIntent, 0)
                    .filter { it.activityInfo.packageName != selfPkg }
                    .map { info ->
                        InstalledAppInfo(
                            label = info.loadLabel(pm).toString().trim(),
                            packageName = info.activityInfo.packageName,
                            activityName = info.activityInfo.name
                        )
                    }
                    .distinctBy { "${it.packageName}/${it.activityName}" }
                    .sortedBy { it.label.lowercase() }
            }
            _installedApps.value = apps
        }
    }

    private fun buildInitialSixSlots(installed: List<InstalledAppInfo>): List<AppSlot> {
        val usedPackages = mutableSetOf<String>()
        return (0 until 6).map { index ->
            val matcher = DefaultPresets.initialSlotMatchers.getOrNull(index)
            val matchedApp = matcher?.second?.firstNotNullOfOrNull { candidatePkg ->
                installed.find { it.packageName.equals(candidatePkg, ignoreCase = true) }
            } ?: installed.firstOrNull { it.packageName !in usedPackages }

            if (matchedApp != null) {
                usedPackages.add(matchedApp.packageName)
                AppSlot(
                    index = index,
                    label = matchedApp.label,
                    packageName = matchedApp.packageName,
                    activityName = matchedApp.activityName,
                    mindfulDelay = false
                )
            } else {
                AppSlot(
                    index = index,
                    label = matcher?.first ?: "Tap to Set",
                    packageName = ""
                )
            }
        }
    }

    fun assignSlot(slotIndex: Int, app: InstalledAppInfo, mindfulDelay: Boolean) {
        viewModelScope.launch {
            val updated = _slots.value.map { slot ->
                if (slot.index == slotIndex) {
                    AppSlot(
                        index = slotIndex,
                        label = app.label,
                        packageName = app.packageName,
                        activityName = app.activityName,
                        mindfulDelay = mindfulDelay
                    )
                } else {
                    slot
                }
            }
            _slots.value = updated
            prefs.saveSlots(updated)
        }
    }

    fun toggleSlotMindfulDelay(slotIndex: Int, enabled: Boolean) {
        viewModelScope.launch {
            val updated = _slots.value.map { slot ->
                if (slot.index == slotIndex) slot.copy(mindfulDelay = enabled) else slot
            }
            _slots.value = updated
            prefs.saveSlots(updated)
        }
    }

    fun launchSlotApp(slot: AppSlot) {
        if (!slot.isAssigned) return
        val app = getApplication<Application>()
        LauncherExitHelper.triggerHaptic(app)
        try {
            val intent = if (slot.activityName.isNotBlank()) {
                Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    component = ComponentName(slot.packageName, slot.activityName)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                }
            } else {
                app.packageManager.getLaunchIntentForPackage(slot.packageName)?.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            }
            if (intent != null) {
                app.startActivity(intent)
            }
        } catch (_: Exception) {
            val fallback = app.packageManager.getLaunchIntentForPackage(slot.packageName)
            fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { app.startActivity(it) }
        }
    }

    // Upper Focus Timer Controls
    fun selectTimerPreset(minutes: Int) {
        pauseTimer()
        val secs = minutes.coerceIn(1, 180) * 60
        _timerTotalSeconds.value = secs
        _timerRemainingSeconds.value = secs
        viewModelScope.launch {
            prefs.setTimerDefaultMinutes(minutes)
        }
    }

    fun toggleTimer() {
        if (_timerRunning.value) {
            pauseTimer()
        } else {
            startTimer()
        }
    }

    private fun startTimer() {
        if (_timerRemainingSeconds.value <= 0) {
            _timerRemainingSeconds.value = _timerTotalSeconds.value
        }
        _timerRunning.value = true
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_timerRunning.value && _timerRemainingSeconds.value > 0) {
                delay(1000L)
                val next = _timerRemainingSeconds.value - 1
                _timerRemainingSeconds.value = next
                if (next <= 0) {
                    _timerRunning.value = false
                    notifyTimerFinished()
                }
            }
        }
    }

    private fun pauseTimer() {
        _timerRunning.value = false
        timerJob?.cancel()
    }

    fun resetTimer() {
        pauseTimer()
        _timerRemainingSeconds.value = _timerTotalSeconds.value
    }

    private fun notifyTimerFinished() {
        val app = getApplication<Application>()
        LauncherExitHelper.triggerHaptic(app, strong = true)
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 450)
        } catch (_: Exception) {
            // Ignore audio errors in silent/DND state
        }
    }

    fun setUse24Hour(enabled: Boolean) {
        viewModelScope.launch { prefs.setUse24Hour(enabled) }
    }

    fun updateIntentionNote(note: String) {
        _intentionNote.value = note
        viewModelScope.launch { prefs.setIntentionNote(note) }
    }

    fun setSwipeNotifications(enabled: Boolean) {
        viewModelScope.launch { prefs.setSwipeDownNotifications(enabled) }
    }
}
