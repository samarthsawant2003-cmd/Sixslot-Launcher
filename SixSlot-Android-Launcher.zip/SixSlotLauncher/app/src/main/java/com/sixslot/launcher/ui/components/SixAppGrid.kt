package com.sixslot.launcher.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sixslot.launcher.model.AppSlot
import com.sixslot.launcher.ui.theme.AccentSky
import com.sixslot.launcher.ui.theme.HairlineBorder
import com.sixslot.launcher.ui.theme.SurfaceDark
import com.sixslot.launcher.ui.theme.TextMuted
import com.sixslot.launcher.ui.theme.TextPrimary

/**
 * SixAppGrid ("app drawer: none"):
 * Renders strictly 6 customizable app slots in a clean 2x3 thumb-friendly layout.
 * - Tap a slot to launch the assigned app.
 * - Long-press any slot (or tap an empty slot) to change which app occupies that slot.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SixAppGrid(
    slots: List<AppSlot>,
    onTapSlot: (AppSlot) -> Unit,
    onEditSlot: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        for (row in 0 until 3) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (col in 0 until 2) {
                    val slotIndex = row * 2 + col
                    val slot = slots.getOrNull(slotIndex)
                        ?: AppSlot(index = slotIndex, label = "Tap to Set", packageName = "")

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(64.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceDark)
                            .border(1.dp, HairlineBorder, RoundedCornerShape(14.dp))
                            .combinedClickable(
                                onClick = {
                                    if (slot.isAssigned) {
                                        onTapSlot(slot)
                                    } else {
                                        onEditSlot(slotIndex)
                                    }
                                },
                                onLongClick = { onEditSlot(slotIndex) }
                            )
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Column {
                            Text(
                                text = if (slot.isAssigned) slot.label else "+ Assign Slot ${slotIndex + 1}",
                                color = if (slot.isAssigned) TextPrimary else TextMuted,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (slot.isAssigned && slot.mindfulDelay) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "3s pause",
                                    color = AccentSky,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
