package com.sixslot.launcher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sixslot.launcher.model.AppSlot
import com.sixslot.launcher.model.DefaultPresets
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sixslot_launcher_prefs")

data class LauncherPersistedState(
    val slots: List<AppSlot>?,
    val use24Hour: Boolean,
    val timerDefaultMinutes: Int,
    val intentionNote: String,
    val swipeDownNotifications: Boolean
)

class LauncherPreferences(private val context: Context) {

    companion object {
        private val KEY_SLOTS_JSON = stringPreferencesKey("slots_json_v1")
        private val KEY_USE_24H = booleanPreferencesKey("use_24_hour")
        private val KEY_TIMER_MINUTES = intPreferencesKey("timer_default_minutes")
        private val KEY_INTENTION_NOTE = stringPreferencesKey("intention_note")
        private val KEY_SWIPE_NOTIFICATIONS = booleanPreferencesKey("swipe_down_notifications")
    }

    val stateFlow: Flow<LauncherPersistedState> = context.dataStore.data.map { prefs ->
        val rawSlots = prefs[KEY_SLOTS_JSON]
        LauncherPersistedState(
            slots = rawSlots?.let { decodeSlots(it) },
            use24Hour = prefs[KEY_USE_24H] ?: DefaultPresets.DEFAULT_USE_24H,
            timerDefaultMinutes = prefs[KEY_TIMER_MINUTES] ?: DefaultPresets.DEFAULT_TIMER_MINUTES,
            intentionNote = prefs[KEY_INTENTION_NOTE] ?: DefaultPresets.DEFAULT_INTENTION,
            swipeDownNotifications = prefs[KEY_SWIPE_NOTIFICATIONS] ?: true
        )
    }

    suspend fun saveSlots(slots: List<AppSlot>) {
        val normalized = (0 until 6).map { idx ->
            slots.find { it.index == idx } ?: AppSlot(index = idx, label = "Empty", packageName = "")
        }
        context.dataStore.edit { prefs ->
            prefs[KEY_SLOTS_JSON] = encodeSlots(normalized)
        }
    }

    suspend fun setUse24Hour(enabled: Boolean) {
        context.dataStore.edit { it[KEY_USE_24H] = enabled }
    }

    suspend fun setTimerDefaultMinutes(minutes: Int) {
        context.dataStore.edit { it[KEY_TIMER_MINUTES] = minutes.coerceIn(1, 180) }
    }

    suspend fun setIntentionNote(note: String) {
        context.dataStore.edit { it[KEY_INTENTION_NOTE] = note.take(90) }
    }

    suspend fun setSwipeDownNotifications(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SWIPE_NOTIFICATIONS] = enabled }
    }

    private fun encodeSlots(slots: List<AppSlot>): String {
        val array = JSONArray()
        slots.forEach { slot ->
            val obj = JSONObject().apply {
                put("index", slot.index)
                put("label", slot.label)
                put("packageName", slot.packageName)
                put("activityName", slot.activityName)
                put("mindfulDelay", slot.mindfulDelay)
            }
            array.put(obj)
        }
        return array.toString()
    }

    private fun decodeSlots(json: String): List<AppSlot>? {
        return try {
            val array = JSONArray(json)
            val result = mutableListOf<AppSlot>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    AppSlot(
                        index = obj.optInt("index", i),
                        label = obj.optString("label", "Slot ${i + 1}"),
                        packageName = obj.optString("packageName", ""),
                        activityName = obj.optString("activityName", ""),
                        mindfulDelay = obj.optBoolean("mindfulDelay", false)
                    )
                )
            }
            if (result.size == 6) result else null
        } catch (_: Exception) {
            null
        }
    }
}
