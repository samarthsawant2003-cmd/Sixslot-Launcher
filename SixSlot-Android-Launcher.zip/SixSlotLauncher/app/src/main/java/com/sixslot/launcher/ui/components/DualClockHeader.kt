package com.sixslot.launcher.ui.components

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sixslot.launcher.ui.theme.AccentSky
import com.sixslot.launcher.ui.theme.HairlineBorder
import com.sixslot.launcher.ui.theme.TextMuted
import com.sixslot.launcher.ui.theme.TextPrimary
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dual Clock Header ("clock: both"):
 * Pairs a clean minimalist Analog clock dial alongside a tabular Digital clock,
 * current date, and live battery status. Tapping opens the phone's system Clock/Alarms.
 */
@Composable
fun DualClockHeader(
    use24Hour: Boolean,
    onClockClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var batteryPct by remember { mutableIntStateOf(100) }
    var isCharging by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent == null) return
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                if (level >= 0 && scale > 0) {
                    batteryPct = ((level * 100f) / scale).toInt()
                }
                isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            }
        }
        context.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        onDispose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
        }
    }

    val calendar = remember(nowMillis) {
        Calendar.getInstance().apply { timeInMillis = nowMillis }
    }
    val dateObj = remember(nowMillis) { Date(nowMillis) }

    val timePattern = if (use24Hour) "HH:mm" else "hh:mm"
    val digitalTime = remember(nowMillis, use24Hour) {
        SimpleDateFormat(timePattern, Locale.getDefault()).format(dateObj)
    }
    val amPm = remember(nowMillis, use24Hour) {
        if (use24Hour) "" else SimpleDateFormat("a", Locale.getDefault()).format(dateObj)
    }
    val dateText = remember(nowMillis) {
        SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(dateObj)
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClockClick
            ),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        // Analog Dial
        AnalogDialCanvas(
            calendar = calendar,
            modifier = Modifier.size(72.dp)
        )

        Spacer(modifier = Modifier.width(18.dp))

        // Digital Readout + Date + Battery
        Column(verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = digitalTime,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 36.sp,
                    lineHeight = 38.sp
                )
                if (amPm.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = amPm,
                        color = TextMuted,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = buildString {
                    append(dateText)
                    append("  ·  ")
                    append("$batteryPct%")
                    if (isCharging) append(" Charging")
                },
                color = TextMuted,
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}

@Composable
private fun AnalogDialCanvas(
    calendar: Calendar,
    modifier: Modifier = Modifier
) {
    val hours = calendar.get(Calendar.HOUR)
    val minutes = calendar.get(Calendar.MINUTE)
    val seconds = calendar.get(Calendar.SECOND)

    Canvas(modifier = modifier) {
        val radius = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        // Outer dial ring
        drawCircle(
            color = HairlineBorder,
            radius = radius - 2.dp.toPx(),
            center = center,
            style = Stroke(width = 1.5.dp.toPx())
        )

        // 12 hour markers
        for (i in 0 until 12) {
            val angleRad = Math.toRadians((i * 30.0) - 90.0)
            val isCardinal = i % 3 == 0
            val outerR = radius - 5.dp.toPx()
            val innerR = outerR - if (isCardinal) 5.dp.toPx() else 2.5.dp.toPx()
            drawLine(
                color = if (isCardinal) TextPrimary.copy(alpha = 0.7f) else TextMuted.copy(alpha = 0.35f),
                start = Offset(
                    center.x + (innerR * cos(angleRad)).toFloat(),
                    center.y + (innerR * sin(angleRad)).toFloat()
                ),
                end = Offset(
                    center.x + (outerR * cos(angleRad)).toFloat(),
                    center.y + (outerR * sin(angleRad)).toFloat()
                ),
                strokeWidth = if (isCardinal) 1.6.dp.toPx() else 1.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // Hour hand
        val hourAngle = Math.toRadians(((hours + minutes / 60.0) * 30.0) - 90.0)
        val hourLen = radius * 0.46f
        drawLine(
            color = TextPrimary,
            start = center,
            end = Offset(
                center.x + (hourLen * cos(hourAngle)).toFloat(),
                center.y + (hourLen * sin(hourAngle)).toFloat()
            ),
            strokeWidth = 2.6.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Minute hand
        val minuteAngle = Math.toRadians(((minutes + seconds / 60.0) * 6.0) - 90.0)
        val minuteLen = radius * 0.68f
        drawLine(
            color = TextPrimary,
            start = center,
            end = Offset(
                center.x + (minuteLen * cos(minuteAngle)).toFloat(),
                center.y + (minuteLen * sin(minuteAngle)).toFloat()
            ),
            strokeWidth = 1.8.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Second hand
        val secondAngle = Math.toRadians((seconds * 6.0) - 90.0)
        val secondLen = radius * 0.74f
        drawLine(
            color = AccentSky,
            start = center,
            end = Offset(
                center.x + (secondLen * cos(secondAngle)).toFloat(),
                center.y + (secondLen * sin(secondAngle)).toFloat()
            ),
            strokeWidth = 1.1.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Center pivot
        drawCircle(
            color = AccentSky,
            radius = 2.5.dp.toPx(),
            center = center
        )
    }
}
