package com.sixslot.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sixslot.launcher.ui.theme.AccentSky
import com.sixslot.launcher.ui.theme.HairlineBorder
import com.sixslot.launcher.ui.theme.ObsidianBg
import com.sixslot.launcher.ui.theme.SurfaceDark
import com.sixslot.launcher.ui.theme.SurfaceElevated
import com.sixslot.launcher.ui.theme.TextMuted
import com.sixslot.launcher.ui.theme.TextPrimary
import java.util.Locale

/**
 * Upper Focus Timer:
 * Positioned directly on the upper side of the 6 app slots so every unlock
 * encourages intentional, time-bounded phone usage.
 */
@Composable
fun UpperFocusTimer(
    totalSeconds: Int,
    remainingSeconds: Int,
    isRunning: Boolean,
    onToggleStartPause: () -> Unit,
    onReset: () -> Unit,
    onSelectPresetMinutes: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val presets = listOf(5, 15, 25, 45)
    val mins = remainingSeconds / 60
    val secs = remainingSeconds % 60
    val formatted = String.format(Locale.US, "%02d:%02d", mins, secs)
    val progress = if (totalSeconds > 0) {
        (remainingSeconds.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark)
            .border(1.dp, HairlineBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = if (isRunning) "Focus Timer · Active" else "Focus Timer",
                    color = TextMuted,
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = formatted,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 26.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isRunning) SurfaceElevated else AccentSky)
                        .clickable(onClick = onToggleStartPause)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isRunning) "Pause" else "Start",
                        color = if (isRunning) TextPrimary else ObsidianBg,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, HairlineBorder, RoundedCornerShape(10.dp))
                        .clickable(onClick = onReset)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Reset",
                        color = TextMuted,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = AccentSky,
            trackColor = HairlineBorder
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presets.forEach { presetMin ->
                val isSelected = totalSeconds == presetMin * 60
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) SurfaceElevated else ObsidianBg)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) AccentSky.copy(alpha = 0.55f) else HairlineBorder,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { onSelectPresetMinutes(presetMin) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${presetMin}m",
                        color = if (isSelected) TextPrimary else TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
