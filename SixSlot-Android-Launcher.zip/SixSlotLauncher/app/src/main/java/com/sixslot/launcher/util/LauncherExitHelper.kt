package com.sixslot.launcher.util

import android.annotation.SuppressLint
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.Settings
import androidx.activity.ComponentActivity

object LauncherExitHelper {

    private fun homeAliasComponent(context: Context): ComponentName {
        return ComponentName(context.packageName, "${context.packageName}.HomeLauncherAlias")
    }

    /**
     * Re-enables the HomeLauncherAlias whenever the user opens SixSlot from their normal launcher,
     * ensuring SixSlot can always be used or re-selected as the default Home screen.
     */
    fun ensureHomeAliasEnabled(context: Context) {
        val pm = context.packageManager
        val alias = homeAliasComponent(context)
        if (pm.getComponentEnabledSetting(alias) != PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
            pm.setComponentEnabledSetting(
                alias,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
        }
    }

    fun isDefaultHomeLauncher(context: Context): Boolean {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
        }
        val resolveInfo = context.packageManager.resolveActivity(
            homeIntent,
            PackageManager.MATCH_DEFAULT_ONLY
        )
        return resolveInfo?.activityInfo?.packageName == context.packageName
    }

    /**
     * Exits SixSlot and immediately returns the user to their phone's normal stock launcher:
     * 1. Steps down from the default CATEGORY_HOME role by disabling HomeLauncherAlias.
     * 2. Resolves the phone's built-in Home launcher package and launches it directly.
     * 3. Finishes the current launcher session cleanly.
     */
    fun exitToNormalLauncher(activity: ComponentActivity) {
        triggerHaptic(activity)
        val pm = activity.packageManager

        // Step 1: Disable HomeLauncherAlias so Android no longer loops back to SixSlot on Home press
        try {
            pm.setComponentEnabledSetting(
                homeAliasComponent(activity),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (_: Exception) {
            // Ignore if already disabled
        }

        // Step 2: Discover the user's normal phone launcher (Pixel Launcher, One UI Home, etc.)
        val homeQuery = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
        }
        val candidates = pm.queryIntentActivities(homeQuery, 0)
            .filter { it.activityInfo.packageName != activity.packageName }

        val targetLauncher = candidates.firstOrNull()
        if (targetLauncher != null) {
            val stockHomeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                component = ComponentName(
                    targetLauncher.activityInfo.packageName,
                    targetLauncher.activityInfo.name
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
            }
            try {
                activity.startActivity(stockHomeIntent)
                activity.finish()
                return
            } catch (_: Exception) {
                // Fall through to generic Home intent
            }
        }

        // Step 3: Generic fallback to system Home or Home App settings
        try {
            val fallbackHome = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            activity.startActivity(fallbackHome)
        } catch (_: Exception) {
            openDefaultHomeSettings(activity)
        }
        activity.finish()
    }

    fun openDefaultHomeSettings(context: Context) {
        ensureHomeAliasEnabled(context)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = context.getSystemService(RoleManager::class.java)
                if (roleManager != null &&
                    roleManager.isRoleAvailable(RoleManager.ROLE_HOME) &&
                    !roleManager.isRoleHeld(RoleManager.ROLE_HOME)
                ) {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
                    if (context is ComponentActivity) {
                        @Suppress("DEPRECATION")
                        context.startActivityForResult(intent, 1001)
                        return
                    }
                }
            }
            context.startActivity(
                Intent(Settings.ACTION_HOME_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
        } catch (_: Exception) {
            context.startActivity(
                Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
        }
    }

    fun openSystemClock(context: Context) {
        try {
            val clockIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(clockIntent)
        } catch (_: Exception) {
            // Ignore if device lacks standard alarm handler
        }
    }

    @SuppressLint("WrongConstant")
    fun expandNotificationShade(context: Context) {
        try {
            val statusBarService = context.getSystemService("statusbar") ?: return
            val statusBarManager = Class.forName("android.app.StatusBarManager")
            val expand = statusBarManager.getMethod("expandNotificationsPanel")
            expand.invoke(statusBarService)
        } catch (_: Exception) {
            // Silently ignore on restricted OEM skins
        }
    }

    fun triggerHaptic(context: Context, strong: Boolean = false) {
        try {
            val durationMs = if (strong) 180L else 22L
            val amplitude = if (strong) VibrationEffect.DEFAULT_AMPLITUDE else 60
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
            }
        } catch (_: Exception) {
            // Ignore if vibration is unavailable
        }
    }
}
