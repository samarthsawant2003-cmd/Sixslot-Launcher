package com.sixslot.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val ObsidianBg = Color(0xFF090B10)
val SurfaceDark = Color(0xFF11151E)
val SurfaceElevated = Color(0xFF171D29)
val HairlineBorder = Color(0xFF222A3A)
val TextPrimary = Color(0xFFF3F6FA)
val TextMuted = Color(0xFF8A94A6)
val AccentSky = Color(0xFF38BDF8)
val DangerMuted = Color(0xFFF87171)

private val SixSlotDarkColors = darkColorScheme(
    primary = AccentSky,
    onPrimary = ObsidianBg,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextMuted,
    outline = HairlineBorder,
    error = DangerMuted
)

private val SixSlotTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        fontSize = 36.sp,
        lineHeight = 40.sp,
        letterSpacing = (-0.5).sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.15.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.2.sp
    )
)

@Composable
fun SixSlotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SixSlotDarkColors,
        typography = SixSlotTypography,
        content = content
    )
}
