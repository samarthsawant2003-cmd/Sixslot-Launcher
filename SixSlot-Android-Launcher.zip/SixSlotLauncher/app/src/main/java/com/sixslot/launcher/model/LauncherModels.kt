package com.sixslot.launcher.model

data class AppSlot(
    val index: Int,
    val label: String,
    val packageName: String,
    val activityName: String = "",
    val mindfulDelay: Boolean = false
) {
    val isAssigned: Boolean
        get() = packageName.isNotBlank()
}

data class InstalledAppInfo(
    val label: String,
    val packageName: String,
    val activityName: String
)

object DefaultPresets {
    const val DEFAULT_TIMER_MINUTES: Int = 25
    const val DEFAULT_USE_24H: Boolean = true
    const val DEFAULT_INTENTION: String = "Unlock with a clear purpose."
    val DEFAULT_MINDFUL_SLOTS: List<Boolean> = listOf(false, false, false, false, false, true)

    /**
     * Pre-configured 6 home screen app slots synced from your SixSlot customizer.
     * Long-press any slot on your phone at any time to swap apps.
     */
    val initialSlotMatchers: List<Pair<String, List<String>>> = listOf(
        "Phone" to listOf(
            "com.google.android.dialer"
        ),
        "Messages" to listOf(
            "com.google.android.apps.messaging"
        ),
        "WhatsApp" to listOf(
            "com.whatsapp"
        ),
        "Maps" to listOf(
            "com.google.android.apps.maps"
        ),
        "Camera" to listOf(
            "com.google.android.GoogleCamera"
        ),
        "Notes" to listOf(
            "com.google.android.keep"
        )
    )
}
