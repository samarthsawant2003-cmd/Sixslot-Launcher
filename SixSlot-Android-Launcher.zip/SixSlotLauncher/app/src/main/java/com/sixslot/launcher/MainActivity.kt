package com.sixslot.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sixslot.launcher.model.AppSlot
import com.sixslot.launcher.ui.LauncherViewModel
import com.sixslot.launcher.ui.components.DualClockHeader
import com.sixslot.launcher.ui.components.SixAppGrid
import com.sixslot.launcher.ui.components.SlotPickerSheet
import com.sixslot.launcher.ui.components.UpperFocusTimer
import com.sixslot.launcher.ui.theme.AccentSky
import com.sixslot.launcher.ui.theme.DangerMuted
import com.sixslot.launcher.ui.theme.HairlineBorder
import com.sixslot.launcher.ui.theme.ObsidianBg
import com.sixslot.launcher.ui.theme.SixSlotTheme
import com.sixslot.launcher.ui.theme.SurfaceDark
import com.sixslot.launcher.ui.theme.TextMuted
import com.sixslot.launcher.ui.theme.TextPrimary
import com.sixslot.launcher.util.LauncherExitHelper
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ensure HomeLauncherAlias is enabled whenever opened so SixSlot is ready to act as Home
        LauncherExitHelper.ensureHomeAliasEnabled(this)
        enableEdgeToEdge()

        setContent {
            SixSlotTheme {
                val vm: LauncherViewModel = viewModel()
                SixSlotHomeScreen(
                    viewModel = vm,
                    onExitLauncher = {
                        LauncherExitHelper.exitToNormalLauncher(this@MainActivity)
                    },
                    onOpenSystemClock = {
                        LauncherExitHelper.openSystemClock(this@MainActivity)
                    },
                    onExpandNotifications = {
                        LauncherExitHelper.expandNotificationShade(this@MainActivity)
                    },
                    onSetDefaultHome = {
                        LauncherExitHelper.openDefaultHomeSettings(this@MainActivity)
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        LauncherExitHelper.ensureHomeAliasEnabled(this)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SixSlotHomeScreen(
    viewModel: LauncherViewModel,
    onExitLauncher: () -> Unit,
    onOpenSystemClock: () -> Unit,
    onExpandNotifications: () -> Unit,
    onSetDefaultHome: () -> Unit
) {
    // Prevent accidental back press from closing the Home screen
    BackHandler(enabled = true) { }

    val slots by viewModel.slots.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val use24Hour by viewModel.use24Hour.collectAsState()
    val intentionNote by viewModel.intentionNote.collectAsState()
    val swipeNotifications by viewModel.swipeNotifications.collectAsState()
    val timerTotal by viewModel.timerTotalSeconds.collectAsState()
    val timerRemaining by viewModel.timerRemainingSeconds.collectAsState()
    val timerRunning by viewModel.timerRunning.collectAsState()

    var editingSlotIndex by remember { mutableStateOf<Int?>(null) }
    var pendingMindfulSlot by remember { mutableStateOf<AppSlot?>(null) }
    var mindfulSecondsLeft by remember { mutableIntStateOf(3) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    LaunchedEffect(pendingMindfulSlot) {
        val target = pendingMindfulSlot ?: return@LaunchedEffect
        mindfulSecondsLeft = 3
        while (mindfulSecondsLeft > 0) {
            delay(1000L)
            mindfulSecondsLeft -= 1
        }
        if (pendingMindfulSlot == target) {
            pendingMindfulSlot = null
            viewModel.launchSlotApp(target)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .pointerInput(swipeNotifications) {
                if (!swipeNotifications) return@pointerInput
                var totalDragY = 0f
                detectVerticalDragGestures(
                    onDragStart = { totalDragY = 0f },
                    onVerticalDrag = { _, dragAmount ->
                        totalDragY += dragAmount
                        if (totalDragY > 90f) {
                            totalDragY = 0f
                            onExpandNotifications()
                        }
                    }
                )
            }
            .systemBarsPadding()
            .padding(horizontal = 22.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Section: Dual Clock (Analog + Digital)
        DualClockHeader(
            use24Hour = use24Hour,
            onClockClick = onOpenSystemClock
        )

        // Center Section: Upper Focus Timer + Strictly 6 Customizable Apps (No App Drawer)
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            UpperFocusTimer(
                totalSeconds = timerTotal,
                remainingSeconds = timerRemaining,
                isRunning = timerRunning,
                onToggleStartPause = viewModel::toggleTimer,
                onReset = viewModel::resetTimer,
                onSelectPresetMinutes = viewModel::selectTimerPreset
            )

            SixAppGrid(
                slots = slots,
                onTapSlot = { slot ->
                    if (slot.mindfulDelay) {
                        pendingMindfulSlot = slot
                    } else {
                        viewModel.launchSlotApp(slot)
                    }
                },
                onEditSlot = { index ->
                    viewModel.refreshInstalledApps()
                    editingSlotIndex = index
                }
            )

            // Quiet one-line daily intention / reminder note
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark.copy(alpha = 0.65f))
                    .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 11.dp)
            ) {
                BasicTextField(
                    value = intentionNote,
                    onValueChange = viewModel::updateIntentionNote,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextMuted),
                    cursorBrush = SolidColor(AccentSky),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { innerTextField ->
                        if (intentionNote.isEmpty()) {
                            Text(
                                text = "Tap to write a 1-line intention...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted.copy(alpha = 0.5f)
                            )
                        }
                        innerTextField()
                    }
                )
            }
        }

        // Bottom Thumb-Zone Bar: Preferences + Exit Launcher Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark)
                    .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                    .clickable { showSettingsSheet = true }
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Settings",
                    color = TextMuted,
                    style = MaterialTheme.typography.labelMedium
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark)
                    .border(1.dp, DangerMuted.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                    .clickable(onClick = onExitLauncher)
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Exit Launcher",
                    color = DangerMuted,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }

    // Slot Replacement Picker (Long-press on any of the 6 slots)
    editingSlotIndex?.let { index ->
        val slot = slots.getOrNull(index) ?: AppSlot(index = index, label = "Slot ${index + 1}", packageName = "")
        SlotPickerSheet(
            slot = slot,
            installedApps = installedApps,
            onSelectApp = { app, mindful ->
                viewModel.assignSlot(index, app, mindful)
            },
            onToggleMindfulOnly = { enabled ->
                viewModel.toggleSlotMindfulDelay(index, enabled)
            },
            onDismiss = { editingSlotIndex = null }
        )
    }

    // 3-Second Mindful Pause Dialog
    pendingMindfulSlot?.let { slot ->
        AlertDialog(
            onDismissRequest = { pendingMindfulSlot = null },
            containerColor = SurfaceDark,
            titleContentColor = TextPrimary,
            textContentColor = TextMuted,
            title = { Text("Opening ${slot.label} in ${mindfulSecondsLeft}s") },
            text = { Text("Take a calm breath. Do you still want to open this app right now?") },
            confirmButton = {
                TextButton(onClick = {
                    val target = slot
                    pendingMindfulSlot = null
                    viewModel.launchSlotApp(target)
                }) {
                    Text("Open Now", color = AccentSky)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingMindfulSlot = null }) {
                    Text("Stay Focused", color = TextPrimary)
                }
            }
        )
    }

    // Minimal Launcher Settings Sheet
    if (showSettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSettingsSheet = false },
            containerColor = SurfaceDark,
            contentColor = TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp)
                    .padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Launcher Preferences",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Tip: Long-press any of the 6 home slots to change its assigned app.",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextMuted
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("24-hour digital clock", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = use24Hour, onCheckedChange = viewModel::setUse24Hour)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Swipe down for notifications", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = swipeNotifications, onCheckedChange = viewModel::setSwipeNotifications)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, HairlineBorder, RoundedCornerShape(12.dp))
                        .clickable {
                            showSettingsSheet = false
                            onSetDefaultHome()
                        }
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Set SixSlot as Default Home App",
                        color = AccentSky,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
