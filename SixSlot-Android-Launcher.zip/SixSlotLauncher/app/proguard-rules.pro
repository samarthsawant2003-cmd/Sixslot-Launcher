-keepattributes *Annotation*
-keepclassmembers class android.app.StatusBarManager {
    public void expandNotificationsPanel();
}
